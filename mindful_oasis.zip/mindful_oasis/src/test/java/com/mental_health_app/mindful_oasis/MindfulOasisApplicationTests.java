package com.mental_health_app.mindful_oasis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindfulOasisApplicationTests {

	@Test
	void contextLoads() {
	}

}
