package com.mental_health_app.mindful_oasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindfulOasisApplication {

	public static void main(String[] args) {

		SpringApplication.run(MindfulOasisApplication.class, args);

		
	}

}
